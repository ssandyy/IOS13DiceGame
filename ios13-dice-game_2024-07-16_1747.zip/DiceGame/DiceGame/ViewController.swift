import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var diceOne: UIImageView!
    
    @IBOutlet weak var diceTwo: UIImageView!
    
    
    @IBAction func rollerButton(_ sender: Any, forEvent event: UIEvent) {
        var dice = [ #imageLiteral(resourceName: "DiceOne"), #imageLiteral(resourceName: "DiceTwo 1"), #imageLiteral(resourceName: "DiceThree"), #imageLiteral(resourceName: "DiceFour 1"), #imageLiteral(resourceName: "DiceFive"), #imageLiteral(resourceName: "DiceSix")]
        
        diceOne.image = dice[Int.random(in: 0...5)]
        diceOne.image = dice[Int.random(in: 0...5)]
        
    }
}
